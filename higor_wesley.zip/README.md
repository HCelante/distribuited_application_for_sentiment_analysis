# distribuited_crawler

![Arch](https://github.com/HCelante/distribuited_application/blob/6a97ee43d3a952fa3d9fd4da676e1d8ab674601d/RMI%20server.png)
