//async function getUser(){
//    const url = "https://api.github.com/users/hcelante"
//    const response = await fetch(url)
//    const result = await response.json()
    //console.log(result)
//    return result
//} export default getUser;